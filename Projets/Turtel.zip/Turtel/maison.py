# Créé par nathanbergeon, le 12/09/2023 en Python 3.7
# CODING UTF-8

from turtle import *

speed('slowest')
shape("turtle")

right(90)
forward(100)
left(90)
forward(100)
left(90)
forward(100)
left(90)
forward(100)
right(120)
forward(100)
right(120)
forward(100)




done()