# Créé par leaneramalingom, le 22/09/2023 en Python 3.7
#Coding UTF-8

from turtle import *


for i in range(3):
    circle(45,180) #RAYON , ARC DE CERCLE
    circle(-45,180)
    left(120)



done()