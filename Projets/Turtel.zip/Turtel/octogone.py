from turtle import *

for k in range(6):
    for j in range(3):
         for i in range(3):
            fd(20)
            left(120)
         fd(100)
         left(120)
    fd(100)
    left(60)

done()



